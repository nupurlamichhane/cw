package Models;

public class Circle {
        static double r;

        public Circle(double r){
            Circle.r = r  ;
        }

        public static double pi = 3.14;
        public static double area(){
            return Math.PI* r * r;
        }
        public static double Circumference(){
            return 2*pi*r;
        }

    }
