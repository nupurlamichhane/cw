// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
package Models;

import Models.Circle;
import Models.cylinder;

public class Main {
    public static void main(String[] args) {
        Circle circle = new Circle(5);
        System.out.println("Area of Circle is: " + Circle.area());
        System.out.println("Circumference of Circle: " + Circle.Circumference());

        cylinder cylinder = new cylinder(5, 10);
        System.out.println("Cylinder volume is: " + cylinder.volume());
        System.out.println("Cylinder area is: " + cylinder.area());
        System.out.println("Cylinder circumference is: " + cylinder.Circumference());
    }
}